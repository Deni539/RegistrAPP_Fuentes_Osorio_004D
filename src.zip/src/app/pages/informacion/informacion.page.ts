import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-informacion',
  templateUrl: './informacion.page.html',
  styleUrls: ['./informacion.page.scss'],
})
export class InformacionPage implements OnInit {

  constructor( private navCtrl: NavController) { }

  ngOnInit() {
  }

  Registro(){
    this.navCtrl.navigateForward('/registro')
  }
  
  Login(){
    this.navCtrl.navigateForward('/login')
  }
}
