import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { Usuario } from '../interfaces/interfaces';
import { AuthService } from 'src/app/servicios/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  usuarios: Usuario={
    username:'',
    nombre: '',
    apellido:'',
    email: '',
    edad: 0,
    password: '',
    jornada: '',
    asignatura1: '',
    asignatura2: '',
    ano: 0,
    semestre: '',
    horas_sem_asig1: 0,
    horas_sem_asig2: 0,
  }

  handlerMessage = '';
  roleMessage = '';

  constructor(private menuController: MenuController,
              private alertController: AlertController,
              private auth: AuthService,
              private router: Router) { }

  ngOnInit() {
  }
  
  crearUsuario(){
    this.auth.CrearUsuario(this.usuarios).subscribe();
    this.router.navigateByUrl("/inicio")
  }

  MostrarMenu(){
    this.menuController.open('first');
  }

  async Enviar(){
    const alert = await this.alertController.create({
      header: 'Bienvenido!' + ' '+ this.usuarios.nombre,
      message: 'Se ha registrado exitosamente!',
      buttons: ['Aceptar'],
    });

    await alert.present();
    this.usuarios.edad=0;
    this.usuarios.nombre='';
    this.usuarios.apellido='';
    this.usuarios.email='';
    this.usuarios.password='';
    this.usuarios.jornada= '';
    this.usuarios.asignatura1= '';
    this.usuarios.asignatura2= '';
    this.usuarios.ano= 0;
    this.usuarios.semestre= '';
    this.usuarios.horas_sem_asig1= 0;
    this.usuarios.horas_sem_asig2= 0;
  }

  
}
