export interface Usuarios{
    id: number;
    username: string;
    nombre: string;
    apellido: string;
    email: string;
    edad: number;
    password: string;
    jornada: string;
    asignatura1: string;
    asignatura2: string;
    ano: number;
    semestre: string;
    horas_sem_asig1: number;
    horas_sem_asig2: number;
    //isdiurno: boolean;
    //isvespertino: boolean;
}

export interface Usuario{

    username: string;
    nombre: string;
    apellido: string;
    email: string;
    edad: number;
    password: string;
    jornada: string;
    asignatura1: string;
    asignatura2: string;
    ano: number;
    semestre: string;
    horas_sem_asig1: number;
    horas_sem_asig2: number;
}

export interface DatosProfes{

    id:number;
    asignatura1: string;
    asignatura2: string;
    ano: number;
    semestre: string;
    horas_sem_asig1: number;
    horas_sem_asig2: number;
}
export interface DatosProfe{

    asignatura1: string;
    asignatura2: string;
    ano: number;
    semestre: string;
    horas_sem_asig1: number;
    horas_sem_asig2: number;
}