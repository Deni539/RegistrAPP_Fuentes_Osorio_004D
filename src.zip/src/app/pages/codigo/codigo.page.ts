import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-codigo',
  templateUrl: './codigo.page.html',
  styleUrls: ['./codigo.page.scss'],
})
export class CodigoPage implements OnInit {

  constructor(private menuController: MenuController,
              private router: Router) { }

  ngOnInit() {
  }

  cerrarCesion() {
    this.router.navigate(['/inicio']);
  }
  Api() {
    this.router.navigate(['/festivos']);
  }

  mostrarMenu() {
    this.menuController.open('first');
  }
  
}
