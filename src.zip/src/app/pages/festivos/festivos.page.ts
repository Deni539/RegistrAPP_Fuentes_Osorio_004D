import { Component, OnInit } from '@angular/core';
import { FestivosService } from 'src/app/servicios/festivos.service';

@Component({
  selector: 'app-festivos',
  templateUrl: './festivos.page.html',
  styleUrls: ['./festivos.page.scss'],
})
export class FestivosPage implements OnInit {
  festivos: any[] = [];

  constructor(private festivosService: FestivosService) { }

  ngOnInit() {
    this.festivos = this.festivosService.obtenerFestivos();
  }

}
