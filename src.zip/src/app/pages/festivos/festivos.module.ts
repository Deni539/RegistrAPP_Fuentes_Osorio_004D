import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FestivosPageRoutingModule } from './festivos-routing.module';

import { FestivosPage } from './festivos.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FestivosPageRoutingModule
  ],
  declarations: [FestivosPage]
})
export class FestivosPageModule {}
