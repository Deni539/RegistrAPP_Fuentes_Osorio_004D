import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FestivosPage } from './festivos.page';

describe('FestivosPage', () => {
  let component: FestivosPage;
  let fixture: ComponentFixture<FestivosPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(FestivosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
