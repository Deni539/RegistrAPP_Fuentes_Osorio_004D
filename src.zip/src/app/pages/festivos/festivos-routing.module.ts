import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FestivosPage } from './festivos.page';

const routes: Routes = [
  {
    path: '',
    component: FestivosPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FestivosPageRoutingModule {}
