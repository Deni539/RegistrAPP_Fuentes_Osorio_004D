import { Component } from '@angular/core';

interface Componente{
  name: string;
  icon: string;
  redirecTo: string; 
}
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor() {}

  componentes: Componente[]=[
    {
      name:'Inicio',
      icon:'star-outline',
      redirecTo:'/inicio'
    },
    {
      name:'Ingresar',
      icon:'person-outline',
      redirecTo:'/login'
    },
    {
      name:'Registro',
      icon:'save-outline',
      redirecTo:'/registro'
    },
    {
      name:'Información',
      icon:'document-text-outline',
      redirecTo:'/informacion'
    },


  ]
}
