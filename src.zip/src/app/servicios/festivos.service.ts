import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FestivosService {
  festivos = [
    {"nombre":"Viernes Santo","comentarios":null,"fecha":"2022-04-15","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Sábado Santo","comentarios":null,"fecha":"2022-04-16","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Día Nacional del Trabajo","comentarios":null,"fecha":"2022-05-01","irrenunciable":"1","tipo":"Civil"},
    {"nombre":"Día de las Glorias Navales","comentarios":null,"fecha":"2022-05-21","irrenunciable":"0","tipo":"Civil"},
    {"nombre":"Día Nacional de los Pueblos Indígenas","comentarios":null,"fecha":"2022-06-21","irrenunciable":"0","tipo":"Civil"},
    {"nombre":"San Pedro y San Pablo","comentarios":null,"fecha":"2022-06-27","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Día de la Virgen del Carmen","comentarios":null,"fecha":"2022-07-16","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Asunción de la Virgen","comentarios":null,"fecha":"2022-08-15","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"16 de Septiembre","comentarios":null,"fecha":"2022-09-16","irrenunciable":"0","tipo":"Civil"},
    {"nombre":"Independencia Nacional","comentarios":null,"fecha":"2022-09-18","irrenunciable":"1","tipo":"Civil"},
    {"nombre":"Día de las Glorias del Ejército","comentarios":null,"fecha":"2022-09-19","irrenunciable":"1","tipo":"Civil"},
    {"nombre":"Encuentro de Dos Mundos","comentarios":null,"fecha":"2022-10-10","irrenunciable":"0","tipo":"Civil"},
    {"nombre":"Día de las Iglesias Evangélicas y Protestantes","comentarios":null,"fecha":"2022-10-31","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Día de Todos los Santos","comentarios":null,"fecha":"2022-11-01","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Inmaculada Concepción","comentarios":null,"fecha":"2022-12-08","irrenunciable":"0","tipo":"Religioso"},
    {"nombre":"Navidad","comentarios":null,"fecha":"2022-12-25","irrenunciable":"1","tipo":"Religioso"}
  ];
  constructor() { }
  obtenerFestivos() {
    return this.festivos;
  }
}
