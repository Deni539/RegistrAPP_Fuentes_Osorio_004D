import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Usuario } from '../pages/interfaces/interfaces'; 
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClient: HttpClient) { }

  CrearUsuario(usuarios:Usuario):Observable<Usuario>{
    return this.httpClient.post<Usuario>(`${environment.apiUrl}/usuarios`, usuarios);
  }

  GetAllUsers():Observable<Usuario>{
    return this.httpClient.get<Usuario>(`${environment.apiUrl}/usuarios`);
  }

  GetUserById(codigo:any): Observable<Usuario>{
    return this.httpClient.get<Usuario>(`${environment.apiUrl}/usuarios/?username=${codigo}`);
  }
  //es para retornar el username del usuario desde sessionStorage
  IsLogged(){
    return sessionStorage.getItem('username')!=null;
  }


}